namespace Sudokugame.Model.Game;

public sealed class CellSnapshot
{
    public int Row { get; }
    public int Column { get; }
    public int Value { get; }
    public bool IsFixed { get; }
    public bool IsHinted { get; }
    public bool IsWrong { get; }
    public bool IsRuleConflict { get; }

    public CellSnapshot(int row, int column, int value, bool isFixed, bool isHinted, bool isWrong, bool isRuleConflict)
    {
        Row = row;
        Column = column;
        Value = value;
        IsFixed = isFixed;
        IsHinted = isHinted;
        IsWrong = isWrong;
        IsRuleConflict = isRuleConflict;
    }
}
