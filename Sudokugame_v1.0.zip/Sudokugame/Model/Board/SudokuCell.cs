namespace Sudokugame.Model.Board;

public sealed class SudokuCell
{
    public int Value { get; private set; }
    public bool IsFixed { get; private set; }
    public bool IsHinted { get; private set; }

    public SudokuCell(int value, bool isFixed)
    {
        if (value < 0 || value > 9)
            throw new ArgumentOutOfRangeException(nameof(value), "Cell value must be in range from 0 to 9.");

        Value = value;
        IsFixed = isFixed;
    }

    public bool TrySetValue(int value)
    {
        if (IsFixed || value < 0 || value > 9)
            return false;

        Value = value;
        return true;
    }

    public void RevealAsHint(int value)
    {
        if (value < 1 || value > 9)
            throw new ArgumentOutOfRangeException(nameof(value), "Hint value must be in range from 1 to 9.");

        Value = value;
        IsFixed = true;
        IsHinted = true;
    }

    public SudokuCell Clone()
    {
        SudokuCell cell = new SudokuCell(Value, IsFixed);

        if (IsHinted)
            cell.MarkAsHinted();

        return cell;
    }

    private void MarkAsHinted()
    {
        IsHinted = true;
    }
}
