using Sudokugame.Model.Game;

namespace Sudokugame.Model.Generation;

public interface ISudokuPuzzleGenerator
{
    SudokuPuzzle CreatePuzzle(DifficultyProfile difficulty);
}
