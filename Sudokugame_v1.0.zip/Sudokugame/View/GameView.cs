using System.Drawing;
using System.Windows.Forms;
using Sudokugame.Controller;
using Sudokugame.Model.Board;
using Sudokugame.Model.Game;

namespace Sudokugame.View;

public sealed class GameView : ObservableSudokuView
{
    private readonly IGameController _controller;
    private readonly SudokuGridView _gridView = new SudokuGridView();
    private readonly Label _difficultyLabel = CreateInfoLabel();
    private readonly Label _timerLabel = CreateInfoLabel();
    private readonly Label _hintsLabel = CreateInfoLabel();
    private readonly Label _mistakesLabel = CreateInfoLabel();
    private readonly Label _emptyCellsLabel = CreateInfoLabel();
    private readonly Label _statusLabel = CreateStatusLabel();
    private readonly List<Button> _numberButtons = new List<Button>();

    private GameStatus _currentStatus = GameStatus.MainMenu;

    public GameView(IGameController controller)
    {
        _controller = controller;
        Dock = DockStyle.Fill;
        Padding = new Padding(16);
        BackColor = Color.FromArgb(245, 247, 250);

        Controls.Add(CreateMainLayout());
        Visible = false;
    }

    protected override void ApplySnapshot(GameStateSnapshot snapshot)
    {
        _currentStatus = snapshot.Status;
        Visible = snapshot.Status != GameStatus.MainMenu;

        if (!Visible)
            return;

        _gridView.ApplyCells(snapshot.Cells);
        UpdateLabels(snapshot);
        UpdateNumberButtons(snapshot.Status == GameStatus.Playing);
    }

    private Control CreateMainLayout()
    {
        TableLayoutPanel layout = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            ColumnCount = 2,
            RowCount = 1
        };

        layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 68));
        layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 32));

        Panel boardPanel = new Panel
        {
            Dock = DockStyle.Fill,
            Padding = new Padding(8),
            BackColor = Color.White
        };

        boardPanel.Controls.Add(_gridView);
        _gridView.CellSelected += _ => UpdateNumberButtons(_currentStatus == GameStatus.Playing);

        layout.Controls.Add(boardPanel, 0, 0);
        layout.Controls.Add(CreateSidePanel(), 1, 0);

        return layout;
    }

    private Control CreateSidePanel()
    {
        FlowLayoutPanel panel = new FlowLayoutPanel
        {
            Dock = DockStyle.Fill,
            FlowDirection = FlowDirection.TopDown,
            WrapContents = false,
            AutoScroll = true,
            Padding = new Padding(16),
            BackColor = Color.White
        };

        Label titleLabel = new Label
        {
            Text = "Судоку",
            Font = new Font("Segoe UI", 24, FontStyle.Bold),
            AutoSize = true,
            Margin = new Padding(0, 0, 0, 18)
        };

        panel.Controls.Add(titleLabel);
        panel.Controls.Add(_difficultyLabel);
        panel.Controls.Add(_timerLabel);
        panel.Controls.Add(_hintsLabel);
        panel.Controls.Add(_mistakesLabel);
        panel.Controls.Add(_emptyCellsLabel);
        panel.Controls.Add(_statusLabel);
        panel.Controls.Add(CreateNumberPanel());
        panel.Controls.Add(CreateActionButton("Очистить клетку", OnClearClicked));
        panel.Controls.Add(CreateActionButton("Подсказка", OnHintClicked));
        panel.Controls.Add(CreateActionButton("Проверить", OnCheckClicked));
        panel.Controls.Add(CreateActionButton("Показать решение", OnSolutionClicked));
        panel.Controls.Add(CreateActionButton("В меню", (_, _) => _controller.ReturnToMenu()));

        return panel;
    }

    private Control CreateNumberPanel()
    {
        TableLayoutPanel panel = new TableLayoutPanel
        {
            Width = 270,
            Height = 150,
            ColumnCount = 3,
            RowCount = 3,
            Margin = new Padding(0, 18, 0, 10)
        };

        for (int index = 0; index < 3; index++)
        {
            panel.RowStyles.Add(new RowStyle(SizeType.Percent, 33.33f));
            panel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 33.33f));
        }

        for (int value = 1; value <= 9; value++)
        {
            Button button = CreateNumberButton(value);
            _numberButtons.Add(button);
            panel.Controls.Add(button, (value - 1) % 3, (value - 1) / 3);
        }

        return panel;
    }

    private Button CreateNumberButton(int value)
    {
        Button button = new Button
        {
            Text = value.ToString(),
            Dock = DockStyle.Fill,
            Font = new Font("Segoe UI", 14, FontStyle.Bold),
            Margin = new Padding(4),
            Tag = value
        };

        button.Click += OnNumberClicked;
        return button;
    }

    private Button CreateActionButton(string text, EventHandler handler)
    {
        Button button = new Button
        {
            Text = text,
            Width = 270,
            Height = 42,
            Font = new Font("Segoe UI", 10, FontStyle.Regular),
            Margin = new Padding(0, 4, 0, 4)
        };

        button.Click += handler;
        return button;
    }

    private void OnNumberClicked(object? sender, EventArgs args)
    {
        if (sender is not Button button || button.Tag is not int value)
            return;

        BoardPosition? selected = _gridView.SelectedPosition;

        if (selected is null)
        {
            MessageBox.Show("Сначала выберите клетку на поле.", "Нет выбранной клетки", MessageBoxButtons.OK, MessageBoxIcon.Information);
            return;
        }

        GameActionResult result = _controller.PlaceNumber(selected, value);
        ShowActionResult(result);
    }

    private void OnClearClicked(object? sender, EventArgs args)
    {
        BoardPosition? selected = _gridView.SelectedPosition;

        if (selected is null)
        {
            MessageBox.Show("Сначала выберите клетку на поле.", "Нет выбранной клетки", MessageBoxButtons.OK, MessageBoxIcon.Information);
            return;
        }

        GameActionResult result = _controller.ClearCell(selected);
        ShowActionResult(result);
    }

    private void OnHintClicked(object? sender, EventArgs args)
    {
        GameActionResult result = _controller.UseHint();
        ShowActionResult(result);
    }

    private void OnCheckClicked(object? sender, EventArgs args)
    {
        GameActionResult result = _controller.CheckBoard();

        if (result.Type == GameActionResultType.BoardIsCorrect)
        {
            MessageBox.Show("Поле заполнено правильно. Судоку решено!", "Проверка", MessageBoxButtons.OK, MessageBoxIcon.Information);
            return;
        }

        if (result.Type == GameActionResultType.BoardHasMistakes)
        {
            string text = $"Пустых клеток: {result.EmptyCells}\nОшибочных клеток: {result.WrongCells}";
            MessageBox.Show(text, "Проверка", MessageBoxButtons.OK, MessageBoxIcon.Information);
            return;
        }

        ShowActionResult(result);
    }

    private void OnSolutionClicked(object? sender, EventArgs args)
    {
        DialogResult dialogResult = MessageBox.Show(
            "Показать решение? Текущая игра будет завершена.",
            "Решение",
            MessageBoxButtons.YesNo,
            MessageBoxIcon.Question);

        if (dialogResult != DialogResult.Yes)
            return;

        GameActionResult result = _controller.ShowSolution();
        ShowActionResult(result);
    }

    private void ShowActionResult(GameActionResult result)
    {
        if (result.IsSuccess)
            return;

        string message = result.Type switch
        {
            GameActionResultType.InvalidPosition => "Выбрана некорректная клетка.",
            GameActionResultType.InvalidValue => "Число должно быть от 1 до 9.",
            GameActionResultType.FixedCell => "Эта клетка была задана изначально или открыта подсказкой. Её нельзя менять.",
            GameActionResultType.GameIsNotRunning => "Сейчас нет активной игры.",
            GameActionResultType.NoHintsLeft => "Подсказки закончились.",
            GameActionResultType.NoHintAvailable => "Нет клеток, для которых можно дать подсказку.",
            _ => "Действие не выполнено."
        };

        MessageBox.Show(message, "Судоку", MessageBoxButtons.OK, MessageBoxIcon.Information);
    }

    private void UpdateLabels(GameStateSnapshot snapshot)
    {
        _difficultyLabel.Text = $"Сложность: {snapshot.Difficulty?.DisplayName ?? "—"}";
        _timerLabel.Text = $"Время: {FormatSeconds(snapshot.ElapsedSeconds)}";
        _hintsLabel.Text = $"Подсказки: {snapshot.HintsLeft}";
        _mistakesLabel.Text = $"Ошибки: {snapshot.Mistakes}/{snapshot.MistakeLimit}";
        _emptyCellsLabel.Text = $"Пустые клетки: {snapshot.EmptyCells}";
        _statusLabel.Text = ResolveStatusText(snapshot.Status);
    }

    private string ResolveStatusText(GameStatus status)
    {
        return status switch
        {
            GameStatus.Playing => "Цель: заполните все клетки без превышения лимита ошибок.",
            GameStatus.Won => "Победа! Вы решили судоку.",
            GameStatus.Lost => "Поражение. Лимит ошибок превышен.",
            GameStatus.SolutionShown => "Игра завершена: решение показано.",
            _ => string.Empty
        };
    }

    private void UpdateNumberButtons(bool enabled)
    {
        foreach (Button button in _numberButtons)
            button.Enabled = enabled && _gridView.SelectedPosition is not null;
    }

    private string FormatSeconds(int seconds)
    {
        TimeSpan time = TimeSpan.FromSeconds(seconds);
        return time.TotalHours >= 1 ? time.ToString(@"hh\:mm\:ss") : time.ToString(@"mm\:ss");
    }

    private static Label CreateInfoLabel()
    {
        return new Label
        {
            Font = new Font("Segoe UI", 11, FontStyle.Regular),
            AutoSize = true,
            Margin = new Padding(0, 4, 0, 4)
        };
    }

    private static Label CreateStatusLabel()
    {
        return new Label
        {
            Font = new Font("Segoe UI", 10, FontStyle.Bold),
            ForeColor = Color.DarkSlateGray,
            AutoSize = false,
            Width = 270,
            Height = 64,
            Margin = new Padding(0, 12, 0, 4)
        };
    }
}
