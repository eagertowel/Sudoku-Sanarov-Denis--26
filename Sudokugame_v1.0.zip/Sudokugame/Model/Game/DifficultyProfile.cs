namespace Sudokugame.Model.Game;

public sealed class DifficultyProfile
{
    public DifficultyLevel Level { get; }
    public string DisplayName { get; }
    public int EmptyCells { get; }
    public int Hints { get; }
    public int MistakeLimit { get; }

    private DifficultyProfile(DifficultyLevel level, string displayName, int emptyCells, int hints, int mistakeLimit)
    {
        Level = level;
        DisplayName = displayName;
        EmptyCells = emptyCells;
        Hints = hints;
        MistakeLimit = mistakeLimit;
    }

    public static DifficultyProfile Create(DifficultyLevel level)
    {
        return level switch
        {
            DifficultyLevel.Easy => new DifficultyProfile(level, "Лёгкий", 35, 5, 6),
            DifficultyLevel.Medium => new DifficultyProfile(level, "Средний", 45, 3, 5),
            DifficultyLevel.Hard => new DifficultyProfile(level, "Сложный", 52, 2, 4),
            DifficultyLevel.Expert => new DifficultyProfile(level, "Эксперт", 58, 1, 3),
            _ => throw new ArgumentOutOfRangeException(nameof(level))
        };
    }
}
