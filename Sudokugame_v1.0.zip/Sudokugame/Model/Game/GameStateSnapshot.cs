namespace Sudokugame.Model.Game;

public sealed class GameStateSnapshot
{
    public GameStatus Status { get; }
    public DifficultyProfile? Difficulty { get; }
    public CellSnapshot[,] Cells { get; }
    public int HintsLeft { get; }
    public int Mistakes { get; }
    public int MistakeLimit { get; }
    public int EmptyCells { get; }
    public int ElapsedSeconds { get; }

    public GameStateSnapshot(
        GameStatus status,
        DifficultyProfile? difficulty,
        CellSnapshot[,] cells,
        int hintsLeft,
        int mistakes,
        int mistakeLimit,
        int emptyCells,
        int elapsedSeconds)
    {
        Status = status;
        Difficulty = difficulty;
        Cells = cells;
        HintsLeft = hintsLeft;
        Mistakes = mistakes;
        MistakeLimit = mistakeLimit;
        EmptyCells = emptyCells;
        ElapsedSeconds = elapsedSeconds;
    }
}
