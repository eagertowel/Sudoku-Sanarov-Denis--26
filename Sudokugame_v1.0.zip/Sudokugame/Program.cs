using System.Text;
using System.Windows.Forms;
using Sudokugame.Controller;
using Sudokugame.Model.Game;
using Sudokugame.Model.Generation;
using Sudokugame.Model.Validation;
using Sudokugame.View;

namespace Sudokugame;

internal static class Program
{
    [STAThread]
    private static void Main()
    {
        try
        {
            Application.SetUnhandledExceptionMode(UnhandledExceptionMode.CatchException);
            Application.ThreadException += (_, args) => ShowFatalError(args.Exception);
            AppDomain.CurrentDomain.UnhandledException += (_, args) =>
            {
                Exception exception = args.ExceptionObject as Exception
                    ?? new InvalidOperationException("Unknown fatal application error.");
                ShowFatalError(exception);
            };

            ApplicationConfiguration.Initialize();

            ISudokuPuzzleGenerator generator = new BacktrackingSudokuPuzzleGenerator();
            ISudokuRuleValidator validator = new SudokuRuleValidator();
            SudokugameModel model = new SudokugameModel(generator, validator);
            IGameController controller = new SudokuController(model);

            Application.Run(new MainForm(model, controller));
        }
        catch (Exception exception)
        {
            ShowFatalError(exception);
        }
    }

    private static void ShowFatalError(Exception exception)
    {
        string logPath = Path.Combine(AppContext.BaseDirectory, "crash.log");
        File.WriteAllText(logPath, exception.ToString(), Encoding.UTF8);

        MessageBox.Show(
            $"Игра не смогла запуститься.\n\n" +
            $"Текст ошибки:\n{exception.Message}\n\n" +
            $"Полный лог сохранён здесь:\n{logPath}",
            "Sudokugame — ошибка запуска",
            MessageBoxButtons.OK,
            MessageBoxIcon.Error);
    }
}
