using Sudokugame.Model.Board;

namespace Sudokugame.Model.Validation;

public sealed class SudokuRuleValidator : ISudokuRuleValidator
{
    private const int Size = 9;
    private const int BoxSize = 3;

    public IReadOnlyCollection<BoardPosition> FindRuleConflicts(int[,] values)
    {
        HashSet<BoardPosition> conflicts = new HashSet<BoardPosition>();

        AddLineConflicts(values, conflicts, readRows: true);
        AddLineConflicts(values, conflicts, readRows: false);
        AddBoxConflicts(values, conflicts);

        return conflicts;
    }

    private void AddLineConflicts(int[,] values, HashSet<BoardPosition> conflicts, bool readRows)
    {
        for (int firstIndex = 0; firstIndex < Size; firstIndex++)
        {
            Dictionary<int, List<BoardPosition>> positionsByValue = new Dictionary<int, List<BoardPosition>>();

            for (int secondIndex = 0; secondIndex < Size; secondIndex++)
            {
                int row = readRows ? firstIndex : secondIndex;
                int column = readRows ? secondIndex : firstIndex;
                int value = values[row, column];

                if (value == 0)
                    continue;

                if (!positionsByValue.ContainsKey(value))
                    positionsByValue[value] = new List<BoardPosition>();

                positionsByValue[value].Add(new BoardPosition(row, column));
            }

            AddDuplicates(positionsByValue, conflicts);
        }
    }

    private void AddBoxConflicts(int[,] values, HashSet<BoardPosition> conflicts)
    {
        for (int boxRow = 0; boxRow < BoxSize; boxRow++)
        {
            for (int boxColumn = 0; boxColumn < BoxSize; boxColumn++)
            {
                Dictionary<int, List<BoardPosition>> positionsByValue = new Dictionary<int, List<BoardPosition>>();

                int startRow = boxRow * BoxSize;
                int startColumn = boxColumn * BoxSize;

                for (int row = startRow; row < startRow + BoxSize; row++)
                {
                    for (int column = startColumn; column < startColumn + BoxSize; column++)
                    {
                        int value = values[row, column];

                        if (value == 0)
                            continue;

                        if (!positionsByValue.ContainsKey(value))
                            positionsByValue[value] = new List<BoardPosition>();

                        positionsByValue[value].Add(new BoardPosition(row, column));
                    }
                }

                AddDuplicates(positionsByValue, conflicts);
            }
        }
    }

    private void AddDuplicates(Dictionary<int, List<BoardPosition>> positionsByValue, HashSet<BoardPosition> conflicts)
    {
        foreach (List<BoardPosition> positions in positionsByValue.Values)
        {
            if (positions.Count <= 1)
                continue;

            foreach (BoardPosition position in positions)
                conflicts.Add(position);
        }
    }
}
