using Sudokugame.Model.Game;

namespace Sudokugame.Model.Generation;

public sealed class BacktrackingSudokuPuzzleGenerator : SudokuPuzzleGeneratorBase
{
    public override SudokuPuzzle CreatePuzzle(DifficultyProfile difficulty)
    {
        int[,] solution = new int[Size, Size];
        FillBoard(solution);

        int[,] board = (int[,])solution.Clone();
        RemoveValues(board, difficulty.EmptyCells);

        return new SudokuPuzzle(board, solution);
    }

    private bool FillBoard(int[,] grid)
    {
        for (int row = 0; row < Size; row++)
        {
            for (int column = 0; column < Size; column++)
            {
                if (grid[row, column] != 0)
                    continue;

                List<int> values = Enumerable.Range(1, 9).ToList();
                Shuffle(values);

                foreach (int value in values)
                {
                    if (!IsAllowed(grid, row, column, value))
                        continue;

                    grid[row, column] = value;

                    if (FillBoard(grid))
                        return true;

                    grid[row, column] = 0;
                }

                return false;
            }
        }

        return true;
    }

    private void RemoveValues(int[,] board, int targetEmptyCells)
    {
        int removed = 0;
        int safetyPasses = 0;

        while (removed < targetEmptyCells && safetyPasses < 6)
        {
            List<(int Row, int Column)> cells = CreateCellList();
            Shuffle(cells);
            bool removedAtLeastOne = false;

            foreach ((int row, int column) in cells)
            {
                if (board[row, column] == 0)
                    continue;

                int backup = board[row, column];
                board[row, column] = 0;

                int[,] copy = (int[,])board.Clone();
                int solutionCount = CountSolutions(copy, 2);

                if (solutionCount == 1)
                {
                    removed++;
                    removedAtLeastOne = true;
                }
                else
                {
                    board[row, column] = backup;
                }

                if (removed >= targetEmptyCells)
                    return;
            }

            if (!removedAtLeastOne)
                return;

            safetyPasses++;
        }
    }

    private int CountSolutions(int[,] grid, int limit)
    {
        if (!TryFindBestEmptyCell(grid, out int row, out int column, out List<int> candidates))
            return 1;

        if (candidates.Count == 0)
            return 0;

        int count = 0;

        foreach (int value in candidates)
        {
            grid[row, column] = value;
            count += CountSolutions(grid, limit);
            grid[row, column] = 0;

            if (count >= limit)
                return count;
        }

        return count;
    }

    private bool TryFindBestEmptyCell(int[,] grid, out int bestRow, out int bestColumn, out List<int> bestCandidates)
    {
        bestRow = -1;
        bestColumn = -1;
        bestCandidates = new List<int>();
        int bestCount = 10;

        for (int row = 0; row < Size; row++)
        {
            for (int column = 0; column < Size; column++)
            {
                if (grid[row, column] != 0)
                    continue;

                List<int> candidates = GetCandidates(grid, row, column);

                if (candidates.Count < bestCount)
                {
                    bestCount = candidates.Count;
                    bestRow = row;
                    bestColumn = column;
                    bestCandidates = candidates;

                    if (bestCount <= 1)
                        return true;
                }
            }
        }

        return bestRow != -1;
    }

    private List<int> GetCandidates(int[,] grid, int row, int column)
    {
        List<int> candidates = new List<int>();

        for (int value = 1; value <= 9; value++)
        {
            if (IsAllowed(grid, row, column, value))
                candidates.Add(value);
        }

        return candidates;
    }

    private List<(int Row, int Column)> CreateCellList()
    {
        List<(int Row, int Column)> cells = new List<(int Row, int Column)>();

        for (int row = 0; row < Size; row++)
        {
            for (int column = 0; column < Size; column++)
            {
                cells.Add((row, column));
            }
        }

        return cells;
    }
}
