using System.Drawing;
using System.Windows.Forms;
using Sudokugame.Model.Game;

namespace Sudokugame.View;

public abstract class ObservableSudokuView : UserControl, IGameObserver
{
    public void OnGameChanged(GameStateSnapshot snapshot)
    {
        if (IsDisposed)
            return;

        if (InvokeRequired && IsHandleCreated)
        {
            BeginInvoke(new Action(() => ApplySnapshot(snapshot)));
            return;
        }

        ApplySnapshot(snapshot);
    }

    protected abstract void ApplySnapshot(GameStateSnapshot snapshot);
}
