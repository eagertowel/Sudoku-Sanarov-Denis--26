namespace Sudokugame.Model.Generation;

public sealed class SudokuPuzzle
{
    public int[,] InitialValues { get; }
    public int[,] SolutionValues { get; }

    public SudokuPuzzle(int[,] initialValues, int[,] solutionValues)
    {
        InitialValues = (int[,])initialValues.Clone();
        SolutionValues = (int[,])solutionValues.Clone();
    }
}
