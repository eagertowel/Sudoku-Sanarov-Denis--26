using Sudokugame.Model.Game;

namespace Sudokugame.Model.Generation;

public abstract class SudokuPuzzleGeneratorBase : ISudokuPuzzleGenerator
{
    protected const int Size = 9;
    protected const int BoxSize = 3;
    protected readonly Random Random = new Random();

    public abstract SudokuPuzzle CreatePuzzle(DifficultyProfile difficulty);

    protected void Shuffle<T>(IList<T> values)
    {
        for (int index = values.Count - 1; index > 0; index--)
        {
            int randomIndex = Random.Next(index + 1);
            (values[index], values[randomIndex]) = (values[randomIndex], values[index]);
        }
    }

    protected bool IsAllowed(int[,] grid, int row, int column, int value)
    {
        for (int index = 0; index < Size; index++)
        {
            if (grid[row, index] == value)
                return false;

            if (grid[index, column] == value)
                return false;
        }

        int startRow = row / BoxSize * BoxSize;
        int startColumn = column / BoxSize * BoxSize;

        for (int currentRow = startRow; currentRow < startRow + BoxSize; currentRow++)
        {
            for (int currentColumn = startColumn; currentColumn < startColumn + BoxSize; currentColumn++)
            {
                if (grid[currentRow, currentColumn] == value)
                    return false;
            }
        }

        return true;
    }
}
