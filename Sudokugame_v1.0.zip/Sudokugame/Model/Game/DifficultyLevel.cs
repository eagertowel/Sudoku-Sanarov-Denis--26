namespace Sudokugame.Model.Game;

public enum DifficultyLevel
{
    Easy,
    Medium,
    Hard,
    Expert
}
