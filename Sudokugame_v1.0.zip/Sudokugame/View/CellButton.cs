using System.Drawing;
using System.Windows.Forms;
using Sudokugame.Model.Board;
using Sudokugame.Model.Game;

namespace Sudokugame.View;

public sealed class CellButton : Button
{
    public BoardPosition Position { get; }

    public CellButton(BoardPosition position)
    {
        Position = position;
        Dock = DockStyle.Fill;
        Margin = CreateCellMargin(position);
        FlatStyle = FlatStyle.Flat;
        Font = new Font("Segoe UI", 16, FontStyle.Bold);
        TabStop = false;
    }

    public void Apply(CellSnapshot snapshot, bool isSelected)
    {
        Text = snapshot.Value == 0 ? string.Empty : snapshot.Value.ToString();
        ForeColor = ResolveTextColor(snapshot);
        BackColor = ResolveBackgroundColor(snapshot, isSelected);
        FlatAppearance.BorderSize = isSelected ? 3 : 1;
        Enabled = true;
    }

    private Color ResolveTextColor(CellSnapshot snapshot)
    {
        if (snapshot.IsWrong)
            return Color.DarkRed;

        if (snapshot.IsFixed && !snapshot.IsHinted)
            return Color.Black;

        if (snapshot.IsHinted)
            return Color.DarkGreen;

        return Color.Navy;
    }

    private Color ResolveBackgroundColor(CellSnapshot snapshot, bool isSelected)
    {
        if (isSelected)
            return Color.LightSkyBlue;

        if (snapshot.IsWrong)
            return Color.MistyRose;

        if (snapshot.IsRuleConflict)
            return Color.LavenderBlush;

        if (snapshot.IsHinted)
            return Color.Honeydew;

        if (snapshot.IsFixed)
            return Color.LemonChiffon;

        return Color.White;
    }

    private Padding CreateCellMargin(BoardPosition position)
    {
        int left = position.Column % 3 == 0 ? 3 : 1;
        int top = position.Row % 3 == 0 ? 3 : 1;
        int right = position.Column == 8 ? 3 : 1;
        int bottom = position.Row == 8 ? 3 : 1;

        return new Padding(left, top, right, bottom);
    }
}
