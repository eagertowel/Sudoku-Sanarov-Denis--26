using System.Drawing;
using System.Windows.Forms;
using Sudokugame.Controller;
using Sudokugame.Model.Game;

namespace Sudokugame.View;

public sealed class MainForm : Form
{
    private readonly SudokugameModel _model;
    private readonly MainMenuView _menuView;
    private readonly GameView _gameView;

    public MainForm(SudokugameModel model, IGameController controller)
    {
        _model = model;

        Text = "Sudokugame";
        StartPosition = FormStartPosition.CenterScreen;
        ClientSize = new Size(1000, 720);
        MinimumSize = new Size(900, 650);

        _gameView = new GameView(controller);
        _menuView = new MainMenuView(controller);

        Controls.Add(_gameView);
        Controls.Add(_menuView);

        _model.RegisterObserver(_menuView);
        _model.RegisterObserver(_gameView);
    }

    protected override void Dispose(bool disposing)
    {
        if (disposing)
        {
            _model.UnregisterObserver(_menuView);
            _model.UnregisterObserver(_gameView);
            _model.Dispose();
        }

        base.Dispose(disposing);
    }
}
