namespace Sudokugame.Model.Game;

public interface IGameObserver
{
    void OnGameChanged(GameStateSnapshot snapshot);
}
