using System.Drawing;
using System.Windows.Forms;
using Sudokugame.Model.Board;
using Sudokugame.Model.Game;

namespace Sudokugame.View;

public sealed class SudokuGridView : UserControl
{
    private readonly CellButton[,] _buttons = new CellButton[9, 9];
    private CellSnapshot[,]? _lastCells;
    private BoardPosition? _selectedPosition;

    public event Action<BoardPosition>? CellSelected;

    public BoardPosition? SelectedPosition => _selectedPosition;

    public SudokuGridView()
    {
        Dock = DockStyle.Fill;
        BackColor = Color.Black;
        Padding = new Padding(4);

        TableLayoutPanel table = CreateTable();
        Controls.Add(table);
    }

    public void ApplyCells(CellSnapshot[,] cells)
    {
        _lastCells = cells;

        for (int row = 0; row < 9; row++)
        {
            for (int column = 0; column < 9; column++)
            {
                CellButton button = _buttons[row, column];
                bool isSelected = _selectedPosition is not null && _selectedPosition.Equals(button.Position);
                button.Apply(cells[row, column], isSelected);
            }
        }
    }

    public void ClearSelection()
    {
        _selectedPosition = null;

        if (_lastCells is not null)
            ApplyCells(_lastCells);
    }

    private TableLayoutPanel CreateTable()
    {
        TableLayoutPanel table = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            RowCount = 9,
            ColumnCount = 9,
            BackColor = Color.Black,
            Padding = new Padding(2)
        };

        for (int index = 0; index < 9; index++)
        {
            table.RowStyles.Add(new RowStyle(SizeType.Percent, 100f / 9f));
            table.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100f / 9f));
        }

        for (int row = 0; row < 9; row++)
        {
            for (int column = 0; column < 9; column++)
            {
                BoardPosition position = new BoardPosition(row, column);
                CellButton button = new CellButton(position);
                button.Click += OnCellClicked;
                _buttons[row, column] = button;
                table.Controls.Add(button, column, row);
            }
        }

        return table;
    }

    private void OnCellClicked(object? sender, EventArgs args)
    {
        if (sender is not CellButton button)
            return;

        _selectedPosition = button.Position;

        if (_lastCells is not null)
            ApplyCells(_lastCells);

        CellSelected?.Invoke(button.Position);
    }
}
