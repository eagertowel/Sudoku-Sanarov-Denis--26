using System.Drawing;
using System.Windows.Forms;
namespace Sudokugame.View;

public sealed class RulesForm : Form
{
    public RulesForm()
    {
        Text = "Правила судоку";
        StartPosition = FormStartPosition.CenterParent;
        ClientSize = new Size(560, 420);
        MinimumSize = new Size(520, 360);

        TextBox rulesBox = new TextBox
        {
            Dock = DockStyle.Fill,
            Multiline = true,
            ReadOnly = true,
            ScrollBars = ScrollBars.Vertical,
            BorderStyle = BorderStyle.None,
            Font = new Font("Segoe UI", 11, FontStyle.Regular),
            BackColor = Color.White,
            Text = BuildRulesText()
        };

        Button closeButton = new Button
        {
            Text = "Закрыть",
            Dock = DockStyle.Bottom,
            Height = 44
        };

        closeButton.Click += (_, _) => Close();

        Padding = new Padding(18);
        Controls.Add(rulesBox);
        Controls.Add(closeButton);
    }

    private string BuildRulesText()
    {
        return "ПРАВИЛА СУДОКУ" + Environment.NewLine + Environment.NewLine +
               "Нужно заполнить поле 9x9 числами от 1 до 9." + Environment.NewLine +
               "В каждой строке, каждом столбце и каждом квадрате 3x3 числа не должны повторяться." + Environment.NewLine + Environment.NewLine +
               "КАК ИГРАТЬ" + Environment.NewLine + Environment.NewLine +
               "1. Выберите пустую клетку мышью." + Environment.NewLine +
               "2. Нажмите кнопку с числом от 1 до 9." + Environment.NewLine +
               "3. Если число ошибочное, клетка подсветится красным и увеличится счётчик ошибок." + Environment.NewLine +
               "4. Чтобы очистить клетку, выберите её и нажмите кнопку 'Очистить клетку'." + Environment.NewLine +
               "5. Кнопка 'Подсказка' открывает одну правильную клетку." + Environment.NewLine +
               "6. Кнопка 'Проверить' показывает количество пустых и ошибочных клеток." + Environment.NewLine + Environment.NewLine +
               "УСЛОВИЯ ФИНАЛА" + Environment.NewLine + Environment.NewLine +
               "Победа: все клетки заполнены правильно." + Environment.NewLine +
               "Поражение: превышен лимит ошибок для выбранной сложности.";
    }
}
