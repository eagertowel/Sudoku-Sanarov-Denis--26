using Sudokugame.Model.Board;
using Sudokugame.Model.Game;

namespace Sudokugame.Controller;

public interface IGameController
{
    void StartNewGame(DifficultyLevel level);
    GameActionResult PlaceNumber(BoardPosition position, int value);
    GameActionResult ClearCell(BoardPosition position);
    GameActionResult UseHint();
    GameActionResult CheckBoard();
    GameActionResult ShowSolution();
    void ReturnToMenu();
}
