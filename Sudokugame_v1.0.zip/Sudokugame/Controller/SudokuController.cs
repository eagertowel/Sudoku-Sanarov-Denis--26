using Sudokugame.Model.Board;
using Sudokugame.Model.Game;

namespace Sudokugame.Controller;

public sealed class SudokuController : IGameController
{
    private readonly SudokugameModel _model;

    public SudokuController(SudokugameModel model)
    {
        _model = model;
    }

    public void StartNewGame(DifficultyLevel level)
    {
        _model.StartNewGame(level);
    }

    public GameActionResult PlaceNumber(BoardPosition position, int value)
    {
        return _model.PlaceNumber(position, value);
    }

    public GameActionResult ClearCell(BoardPosition position)
    {
        return _model.ClearCell(position);
    }

    public GameActionResult UseHint()
    {
        return _model.UseHint();
    }

    public GameActionResult CheckBoard()
    {
        return _model.CheckBoard();
    }

    public GameActionResult ShowSolution()
    {
        return _model.ShowSolution();
    }

    public void ReturnToMenu()
    {
        _model.ReturnToMenu();
    }
}
