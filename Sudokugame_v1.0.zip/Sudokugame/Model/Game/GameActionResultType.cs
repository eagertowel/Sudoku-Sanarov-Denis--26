namespace Sudokugame.Model.Game;

public enum GameActionResultType
{
    Success,
    InvalidPosition,
    InvalidValue,
    FixedCell,
    GameIsNotRunning,
    NoHintsLeft,
    NoHintAvailable,
    BoardIsCorrect,
    BoardHasMistakes
}
