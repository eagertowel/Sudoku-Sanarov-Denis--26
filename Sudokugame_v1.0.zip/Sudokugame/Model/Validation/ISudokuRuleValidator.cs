using Sudokugame.Model.Board;

namespace Sudokugame.Model.Validation;

public interface ISudokuRuleValidator
{
    IReadOnlyCollection<BoardPosition> FindRuleConflicts(int[,] values);
}
