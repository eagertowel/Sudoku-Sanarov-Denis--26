namespace Sudokugame.Model.Board;

public sealed class SudokuBoard
{
    private const int Size = 9;
    private readonly SudokuCell[,] _cells;

    public SudokuBoard(int[,] initialValues)
    {
        if (initialValues.GetLength(0) != Size || initialValues.GetLength(1) != Size)
            throw new ArgumentException("Sudoku board must be 9x9.", nameof(initialValues));

        _cells = new SudokuCell[Size, Size];

        for (int row = 0; row < Size; row++)
        {
            for (int column = 0; column < Size; column++)
            {
                int value = initialValues[row, column];

                if (value < 0 || value > 9)
                    throw new ArgumentException("Sudoku cell values must be in range from 0 to 9.", nameof(initialValues));

                _cells[row, column] = new SudokuCell(value, value != 0);
            }
        }
    }

    public SudokuCell GetCell(BoardPosition position)
    {
        return _cells[position.Row, position.Column];
    }

    public bool TrySetValue(BoardPosition position, int value)
    {
        return _cells[position.Row, position.Column].TrySetValue(value);
    }

    public void RevealCellAsHint(BoardPosition position, int value)
    {
        _cells[position.Row, position.Column].RevealAsHint(value);
    }

    public int CountEmptyCells()
    {
        int count = 0;

        for (int row = 0; row < Size; row++)
        {
            for (int column = 0; column < Size; column++)
            {
                if (_cells[row, column].Value == 0)
                    count++;
            }
        }

        return count;
    }

    public int[,] CopyValues()
    {
        int[,] values = new int[Size, Size];

        for (int row = 0; row < Size; row++)
        {
            for (int column = 0; column < Size; column++)
            {
                values[row, column] = _cells[row, column].Value;
            }
        }

        return values;
    }

    public bool[,] CopyFixedFlags()
    {
        bool[,] values = new bool[Size, Size];

        for (int row = 0; row < Size; row++)
        {
            for (int column = 0; column < Size; column++)
            {
                values[row, column] = _cells[row, column].IsFixed;
            }
        }

        return values;
    }

    public bool[,] CopyHintedFlags()
    {
        bool[,] values = new bool[Size, Size];

        for (int row = 0; row < Size; row++)
        {
            for (int column = 0; column < Size; column++)
            {
                values[row, column] = _cells[row, column].IsHinted;
            }
        }

        return values;
    }
}
