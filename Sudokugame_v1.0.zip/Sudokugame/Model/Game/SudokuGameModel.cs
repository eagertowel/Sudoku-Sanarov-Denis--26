using Sudokugame.Model.Board;
using Sudokugame.Model.Generation;
using Sudokugame.Model.Validation;

namespace Sudokugame.Model.Game;

public sealed class SudokugameModel : IDisposable
{
    private const int Size = 9;
    private readonly ISudokuPuzzleGenerator _generator;
    private readonly ISudokuRuleValidator _ruleValidator;
    private readonly List<IGameObserver> _observers = new List<IGameObserver>();
    private readonly object _syncRoot = new object();
    private readonly Random _random = new Random();

    private SudokuBoard? _board;
    private int[,]? _solution;
    private DifficultyProfile? _difficulty;
    private GameStatus _status = GameStatus.MainMenu;
    private int _hintsLeft;
    private int _mistakes;
    private int _elapsedSeconds;
    private DateTime _startedAtUtc;
    private System.Threading.Timer? _clockTimer;
    private bool _disposed;

    public SudokugameModel(ISudokuPuzzleGenerator generator, ISudokuRuleValidator ruleValidator)
    {
        _generator = generator;
        _ruleValidator = ruleValidator;
    }

    public void RegisterObserver(IGameObserver observer)
    {
        lock (_syncRoot)
        {
            if (!_observers.Contains(observer))
                _observers.Add(observer);
        }

        observer.OnGameChanged(CreateSnapshot());
    }

    public void UnregisterObserver(IGameObserver observer)
    {
        lock (_syncRoot)
        {
            _observers.Remove(observer);
        }
    }

    public void StartNewGame(DifficultyLevel level)
    {
        DifficultyProfile difficulty = DifficultyProfile.Create(level);
        SudokuPuzzle puzzle = _generator.CreatePuzzle(difficulty);

        lock (_syncRoot)
        {
            _difficulty = difficulty;
            _board = new SudokuBoard(puzzle.InitialValues);
            _solution = (int[,])puzzle.SolutionValues.Clone();
            _status = GameStatus.Playing;
            _hintsLeft = difficulty.Hints;
            _mistakes = 0;
            _elapsedSeconds = 0;
            _startedAtUtc = DateTime.UtcNow;
        }

        StartClock();
        NotifyObservers();
    }

    public GameActionResult PlaceNumber(BoardPosition position, int value)
    {
        if (value < 1 || value > 9)
            return GameActionResult.Failure(GameActionResultType.InvalidValue);

        lock (_syncRoot)
        {
            if (!IsGameRunning())
                return GameActionResult.Failure(GameActionResultType.GameIsNotRunning);

            if (_board is null || _solution is null || !BoardPosition.IsValid(position.Row, position.Column))
                return GameActionResult.Failure(GameActionResultType.InvalidPosition);

            SudokuCell cell = _board.GetCell(position);

            if (cell.IsFixed)
                return GameActionResult.Failure(GameActionResultType.FixedCell);

            _board.TrySetValue(position, value);

            if (value != _solution[position.Row, position.Column])
            {
                _mistakes++;

                if (_difficulty is not null && _mistakes >= _difficulty.MistakeLimit)
                {
                    _status = GameStatus.Lost;
                    StopClock();
                }
            }
            else if (IsSolvedUnsafe())
            {
                _status = GameStatus.Won;
                StopClock();
            }
        }

        NotifyObservers();
        return GameActionResult.Success();
    }

    public GameActionResult ClearCell(BoardPosition position)
    {
        lock (_syncRoot)
        {
            if (!IsGameRunning())
                return GameActionResult.Failure(GameActionResultType.GameIsNotRunning);

            if (_board is null || !BoardPosition.IsValid(position.Row, position.Column))
                return GameActionResult.Failure(GameActionResultType.InvalidPosition);

            SudokuCell cell = _board.GetCell(position);

            if (cell.IsFixed)
                return GameActionResult.Failure(GameActionResultType.FixedCell);

            _board.TrySetValue(position, 0);
        }

        NotifyObservers();
        return GameActionResult.Success();
    }

    public GameActionResult UseHint()
    {
        lock (_syncRoot)
        {
            if (!IsGameRunning())
                return GameActionResult.Failure(GameActionResultType.GameIsNotRunning);

            if (_hintsLeft <= 0)
                return GameActionResult.Failure(GameActionResultType.NoHintsLeft);

            if (_board is null || _solution is null)
                return GameActionResult.Failure(GameActionResultType.GameIsNotRunning);

            List<BoardPosition> positions = FindHintPositionsUnsafe();

            if (positions.Count == 0)
                return GameActionResult.Failure(GameActionResultType.NoHintAvailable);

            BoardPosition hintPosition = positions[_random.Next(positions.Count)];
            _board.RevealCellAsHint(hintPosition, _solution[hintPosition.Row, hintPosition.Column]);
            _hintsLeft--;

            if (IsSolvedUnsafe())
            {
                _status = GameStatus.Won;
                StopClock();
            }
        }

        NotifyObservers();
        return GameActionResult.Success();
    }

    public GameActionResult CheckBoard()
    {
        lock (_syncRoot)
        {
            if (_board is null || _solution is null)
                return GameActionResult.Failure(GameActionResultType.GameIsNotRunning);

            int emptyCells = 0;
            int wrongCells = 0;

            for (int row = 0; row < Size; row++)
            {
                for (int column = 0; column < Size; column++)
                {
                    int value = _board.GetCell(new BoardPosition(row, column)).Value;

                    if (value == 0)
                        emptyCells++;
                    else if (value != _solution[row, column])
                        wrongCells++;
                }
            }

            return GameActionResult.CheckResult(emptyCells, wrongCells);
        }
    }

    public GameActionResult ShowSolution()
    {
        lock (_syncRoot)
        {
            if (_board is null || _solution is null)
                return GameActionResult.Failure(GameActionResultType.GameIsNotRunning);

            for (int row = 0; row < Size; row++)
            {
                for (int column = 0; column < Size; column++)
                {
                    BoardPosition position = new BoardPosition(row, column);
                    _board.RevealCellAsHint(position, _solution[row, column]);
                }
            }

            _status = GameStatus.SolutionShown;
            StopClock();
        }

        NotifyObservers();
        return GameActionResult.Success();
    }

    public void ReturnToMenu()
    {
        lock (_syncRoot)
        {
            _status = GameStatus.MainMenu;
            StopClock();
        }

        NotifyObservers();
    }

    public void Dispose()
    {
        if (_disposed)
            return;

        _clockTimer?.Dispose();
        _disposed = true;
    }

    private bool IsGameRunning()
    {
        return _status == GameStatus.Playing;
    }

    private void StartClock()
    {
        _clockTimer?.Dispose();
        _clockTimer = new System.Threading.Timer(OnClockTick, null, 1000, 1000);
    }

    private void StopClock()
    {
        UpdateElapsedSecondsUnsafe();
        _clockTimer?.Dispose();
        _clockTimer = null;
    }

    private void OnClockTick(object? state)
    {
        bool shouldNotify;

        lock (_syncRoot)
        {
            shouldNotify = _status == GameStatus.Playing;

            if (shouldNotify)
                UpdateElapsedSecondsUnsafe();
        }

        if (shouldNotify)
            NotifyObservers();
    }

    private void UpdateElapsedSecondsUnsafe()
    {
        if (_status == GameStatus.Playing)
            _elapsedSeconds = Math.Max(0, (int)(DateTime.UtcNow - _startedAtUtc).TotalSeconds);
    }

    private bool IsSolvedUnsafe()
    {
        if (_board is null || _solution is null)
            return false;

        for (int row = 0; row < Size; row++)
        {
            for (int column = 0; column < Size; column++)
            {
                if (_board.GetCell(new BoardPosition(row, column)).Value != _solution[row, column])
                    return false;
            }
        }

        return true;
    }

    private List<BoardPosition> FindHintPositionsUnsafe()
    {
        List<BoardPosition> positions = new List<BoardPosition>();

        if (_board is null || _solution is null)
            return positions;

        for (int row = 0; row < Size; row++)
        {
            for (int column = 0; column < Size; column++)
            {
                BoardPosition position = new BoardPosition(row, column);
                SudokuCell cell = _board.GetCell(position);

                if (!cell.IsFixed && cell.Value != _solution[row, column])
                    positions.Add(position);
            }
        }

        return positions;
    }

    private GameStateSnapshot CreateSnapshot()
    {
        lock (_syncRoot)
        {
            CellSnapshot[,] cells = CreateCellSnapshotsUnsafe();

            return new GameStateSnapshot(
                _status,
                _difficulty,
                cells,
                _hintsLeft,
                _mistakes,
                _difficulty?.MistakeLimit ?? 0,
                _board?.CountEmptyCells() ?? 81,
                _elapsedSeconds);
        }
    }

    private CellSnapshot[,] CreateCellSnapshotsUnsafe()
    {
        CellSnapshot[,] snapshots = new CellSnapshot[Size, Size];

        if (_board is null || _solution is null)
        {
            for (int row = 0; row < Size; row++)
            {
                for (int column = 0; column < Size; column++)
                {
                    snapshots[row, column] = new CellSnapshot(row, column, 0, false, false, false, false);
                }
            }

            return snapshots;
        }

        int[,] values = _board.CopyValues();
        HashSet<BoardPosition> conflictPositions = _ruleValidator.FindRuleConflicts(values).ToHashSet();

        for (int row = 0; row < Size; row++)
        {
            for (int column = 0; column < Size; column++)
            {
                BoardPosition position = new BoardPosition(row, column);
                SudokuCell cell = _board.GetCell(position);
                bool isWrong = cell.Value != 0 && !cell.IsFixed && cell.Value != _solution[row, column];
                bool isConflict = conflictPositions.Contains(position);

                snapshots[row, column] = new CellSnapshot(row, column, cell.Value, cell.IsFixed, cell.IsHinted, isWrong, isConflict);
            }
        }

        return snapshots;
    }

    private void NotifyObservers()
    {
        GameStateSnapshot snapshot = CreateSnapshot();
        IGameObserver[] observers;

        lock (_syncRoot)
        {
            observers = _observers.ToArray();
        }

        foreach (IGameObserver observer in observers)
            observer.OnGameChanged(snapshot);
    }
}
