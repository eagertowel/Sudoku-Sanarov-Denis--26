using System;
using System.Drawing;
using System.Windows.Forms;
using Sudokugame.Controller;
using Sudokugame.Model.Game;

namespace Sudokugame.View;

public sealed class MainMenuView : ObservableSudokuView
{
    private readonly IGameController _controller;

    public MainMenuView(IGameController controller)
    {
        _controller = controller;
        Dock = DockStyle.Fill;
        BackColor = Color.FromArgb(245, 247, 250);
        Controls.Add(CreateLayout());
    }

    protected override void ApplySnapshot(GameStateSnapshot snapshot)
    {
        Visible = snapshot.Status == GameStatus.MainMenu;
    }

    private Control CreateLayout()
    {
        TableLayoutPanel root = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            ColumnCount = 3,
            RowCount = 3
        };

        root.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50));
        root.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 460));
        root.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50));
        root.RowStyles.Add(new RowStyle(SizeType.Percent, 50));
        root.RowStyles.Add(new RowStyle(SizeType.Absolute, 560));
        root.RowStyles.Add(new RowStyle(SizeType.Percent, 50));

        Panel menuPanel = new Panel
        {
            Dock = DockStyle.Fill,
            BackColor = Color.White,
            Padding = new Padding(24)
        };

        TableLayoutPanel centeredContainer = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            ColumnCount = 1,
            RowCount = 3
        };

        centeredContainer.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
        centeredContainer.RowStyles.Add(new RowStyle(SizeType.Percent, 50));
        centeredContainer.RowStyles.Add(new RowStyle(SizeType.AutoSize));
        centeredContainer.RowStyles.Add(new RowStyle(SizeType.Percent, 50));

        FlowLayoutPanel menuItems = new FlowLayoutPanel
        {
            AutoSize = true,
            AutoSizeMode = AutoSizeMode.GrowAndShrink,
            Anchor = AnchorStyles.None,
            FlowDirection = FlowDirection.TopDown,
            WrapContents = false
        };

        Label title = new Label
        {
            Text = "СУДОКУ",
            Font = new Font("Segoe UI", 34, FontStyle.Bold),
            AutoSize = false,
            TextAlign = ContentAlignment.MiddleCenter,
            Width = 380,
            Height = 100,
            Margin = new Padding(0, 0, 0, 24)
        };

        menuItems.Controls.Add(title);
        menuItems.Controls.Add(CreateDifficultyButton("Новая игра: лёгкий", DifficultyLevel.Easy));
        menuItems.Controls.Add(CreateDifficultyButton("Новая игра: средний", DifficultyLevel.Medium));
        menuItems.Controls.Add(CreateDifficultyButton("Новая игра: сложный", DifficultyLevel.Hard));
        menuItems.Controls.Add(CreateDifficultyButton("Новая игра: эксперт", DifficultyLevel.Expert));
        menuItems.Controls.Add(CreateMenuButton("Правила", (_, _) => new RulesForm().ShowDialog(FindForm())));
        menuItems.Controls.Add(CreateMenuButton("Выход", (_, _) => FindForm()?.Close()));

        centeredContainer.Controls.Add(menuItems, 0, 1);
        menuPanel.Controls.Add(centeredContainer);
        root.Controls.Add(menuPanel, 1, 1);

        return root;
    }

    private Button CreateDifficultyButton(string text, DifficultyLevel level)
    {
        return CreateMenuButton(text, (_, _) => _controller.StartNewGame(level));
    }

    private Button CreateMenuButton(string text, EventHandler handler)
    {
        Button button = new Button
        {
            Text = text,
            Width = 380,
            Height = 48,
            Font = new Font("Segoe UI", 11, FontStyle.Bold),
            Margin = new Padding(0, 6, 0, 6)
        };

        button.Click += handler;
        return button;
    }
}
