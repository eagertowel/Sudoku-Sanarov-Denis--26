namespace Sudokugame.Model.Game;

public sealed class GameActionResult
{
    public GameActionResultType Type { get; }
    public bool IsSuccess { get; }
    public int EmptyCells { get; }
    public int WrongCells { get; }

    private GameActionResult(GameActionResultType type, bool isSuccess, int emptyCells, int wrongCells)
    {
        Type = type;
        IsSuccess = isSuccess;
        EmptyCells = emptyCells;
        WrongCells = wrongCells;
    }

    public static GameActionResult Success()
    {
        return new GameActionResult(GameActionResultType.Success, true, 0, 0);
    }

    public static GameActionResult Failure(GameActionResultType type)
    {
        return new GameActionResult(type, false, 0, 0);
    }

    public static GameActionResult CheckResult(int emptyCells, int wrongCells)
    {
        GameActionResultType type = wrongCells == 0 && emptyCells == 0
            ? GameActionResultType.BoardIsCorrect
            : GameActionResultType.BoardHasMistakes;

        return new GameActionResult(type, wrongCells == 0, emptyCells, wrongCells);
    }
}
