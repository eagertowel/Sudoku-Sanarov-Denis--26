namespace Sudokugame.Model.Board;

public sealed class BoardPosition : IEquatable<BoardPosition>
{
    public int Row { get; }
    public int Column { get; }

    public BoardPosition(int row, int column)
    {
        if (!IsValid(row, column))
            throw new ArgumentOutOfRangeException(nameof(row), "Row and column must be in range from 0 to 8.");

        Row = row;
        Column = column;
    }

    public static bool IsValid(int row, int column)
    {
        return row >= 0 && row < 9 && column >= 0 && column < 9;
    }

    public bool Equals(BoardPosition? other)
    {
        return other is not null && Row == other.Row && Column == other.Column;
    }

    public override bool Equals(object? obj)
    {
        return Equals(obj as BoardPosition);
    }

    public override int GetHashCode()
    {
        return HashCode.Combine(Row, Column);
    }
}
