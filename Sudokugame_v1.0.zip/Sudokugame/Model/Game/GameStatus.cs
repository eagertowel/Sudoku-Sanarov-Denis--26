namespace Sudokugame.Model.Game;

public enum GameStatus
{
    MainMenu,
    Playing,
    Won,
    Lost,
    SolutionShown
}
